<footer class="bg-blue-700 text-white text-center py-4 mt-10">
    <p class="text-sm">&copy; <?php echo date("Y"); ?> STI Scheduler. All rights reserved.</p>
</footer>